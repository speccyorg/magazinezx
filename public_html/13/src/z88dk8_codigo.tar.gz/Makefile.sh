#! /bin/bash

cd cwrapper
cp ../SPconfig.def .
cc -o GenCompile GenCompile.c
./GenCompile "zcc +zx -vn -make-lib -I.." sp_c.lst
rm SPconfig.def
cd ..

cd hashtable
cp ../SPconfig.def .
cc -o GenCompile GenCompile.c
./GenCompile "zcc +zx -vn -make-lib -I.." sp_c.lst
rm SPconfig.def
cd ..

cd heap
cp ../SPconfig.def .
cc -o GenCompile GenCompile.c
./GenCompile "zcc +zx -vn -make-lib -I.." sp_c.lst
rm SPconfig.def
cd ..

cd huffman
cp ../SPconfig.def .
cc -o GenCompile GenCompile.c
./GenCompile "zcc +zx -vn -make-lib -I.." sp_c.lst
rm SPconfig.def
cd ..

z80asm -I. -d -ns -nm -Mo -DFORzx -xsplib2 @sp.lst

cd backgroundtiles
rm *.o
cd ..

cd blockmemoryalloc
rm *.o
cd ..

cd cwrapper
rm *.o
cd ..

cd displaylist
rm *.o
cd ..

cd globalvariables
rm *.o
cd ..

cd hashtable
rm *.o
cd ..

cd heap
rm *.o
cd ..

cd huffman
rm *.o
cd ..

cd input
rm *.o
cd ..

cd interrupts
rm *.o
cd ..

cd linkedlist
rm *.o
cd ..

cd miscellaneous
rm *.o
cd ..

cd screenaddress
rm *.o
cd ..

cd sprites
rm *.o
cd ..

cd updater
rm *.o
cd ..
