
#include <spritepack.h>
#include <stdlib.h>
#pragma output STACKPTR=61440

extern struct sp_Rect *sp_ClipStruct;
#asm
LIB SPCClipStruct
._sp_ClipStruct         defw SPCClipStruct
#endasm

extern uchar bicho1[];
extern uchar bicho2[];
extern uchar bicho3[];
uchar hash[] = {0x55,0xaa,0x55,0xaa,0x55,0xaa,0x55,0xaa};

void *my_malloc(uint bytes)
{
	   return sp_BlockAlloc(0);
}

void *u_malloc = my_malloc;
void *u_free = sp_FreeBlock;


main()
{
	   char dx, dy, i;
	   struct sp_SS *spriteBicho;

	    #asm
	    di
	    #endasm
	    sp_InitIM2(0xf1f1);
	    sp_CreateGenericISR(0xf1f1);
	    #asm
	    ei
	    #endasm
						    
	   sp_TileArray(' ', hash);
	   sp_Initialize(INK_WHITE | PAPER_BLACK, ' ');
	   sp_Border(CYAN);
	   sp_AddMemory(0, 255, 14, 0xb000);


           spriteBicho = sp_CreateSpr(sp_MASK_SPRITE, 3, bicho1, 1, TRANSPARENT);
           sp_AddColSpr(spriteBicho, bicho2, TRANSPARENT);
	   sp_AddColSpr(spriteBicho, bicho3, TRANSPARENT);
           sp_MoveSprAbs(spriteBicho, sp_ClipStruct, 0, 10, 15, 0, 0);

           while(1) {
  	         sp_UpdateNow();
   	         
		 dx = dy = 1;

		if (rand()%2 == 0) // izquierda
			dx = -dx;
		else if (rand()%2 == 0) // derecha
		        dx = 0;
		if (rand()%2 == 0) // arriba
		        dy = -dy;
		else if (rand()%2 == 0) // abajo
		        dy = 0;
       
	        sp_MoveSprRel(spriteBicho, sp_ClipStruct, 0, 0, 0, dx, dy);
	   }
}

#asm

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._bicho1
defb @00000011, @11111100
defb @00000100, @11111000
defb @00001000, @11110000
defb @00001011, @11110000
defb @00001011, @11110000
defb @00001000, @11110000
defb @00001000, @11110000
defb @00000100, @11111000

defb @00000011, @11111100
defb @00001100, @11110011
defb @00001100, @11110011
defb @00011000, @11100111
defb @00011000, @11100111
defb @01111100, @10000011
defb @01111100, @10000011
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._bicho2
defb @11100000, @00011111
defb @00010000, @00001111
defb @00001000, @00000111
defb @01101000, @00000111
defb @01101000, @00000111
defb @00001000, @00000111
defb @10001000, @00000111
defb @10010000, @00001111

defb @11100000, @00011111
defb @00011000, @11100111
defb @00011000, @11100111
defb @00001100, @11110011
defb @00001100, @11110011
defb @00111110, @11000001
defb @00111110, @11000001
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._bicho3
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

#endasm


