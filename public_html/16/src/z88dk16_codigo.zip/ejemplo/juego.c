#include <sprites/sp1.h>
#include <malloc.h>
#include <spectrum.h>
#include <input.h>

#pragma output STACKPTR = 53248     // Dirección de inicio de la pila (0xd000)

// Declaracion de la pila, necesaria para usar MALLOC.LIB
long heap;

struct personaje {
   struct sp1_ss  *sprite;
   char           dx;
   char           dy;
   struct in_UDK keys;
   void *getjoy;
   uchar *frameoffset;		
};

extern uchar prota_col0[];
extern uchar enemigo_col0[];
short int posiciones[] = {5,4,20,25,20,3,1,5,12,12,18,18};
short int desplazamientos[] = {1,1,-1,1,1,-1,-1,-1,-1,-1,1,1};

// Definición de políticas de reserva y liberación de memoria, utilizadas por splib
// para hacer uso de este recurso
void *u_malloc(uint size)
{
   return malloc(size);
}

void u_free(void *addr)
{
   free(addr);
}

// Definición del tile que utilizaremos de fondo en todas las posiciones
uchar fondo[] = {0x80,0x00,0x04,0x00,0x40,0x00,0x02,0x00}; 
// Definimos el area total en tiles (32x24 tiles) para poder inicializar toda la pantalla
struct sp1_Rect cr = {0, 0, 32, 24};  

main()
{
   struct personaje p;
   uchar input;
   struct personaje enemigos[6];
   int i;
   int xp, yp;
   int xe, ye;
   short int final;
   
   #asm
   // Las interrupciones son deshabilitadas totalmente al usar SP1, pues esta libreria usa el 
   // registro IY, por lo que entra en conflicto con las rutinas de la ROM relacionadas con este tema
   di
   #endasm
   
   // Inicialización de MALLOC.LIB
   heap = 0L;                       // La pila está vacía
   sbrk(40000, 10000);              // Se le añade a la pila la memoria desde 40000 a 49999, ambos inclusive

   // El borde pasa a ser azul (esto es de spectrum.h)
   zx_border(BLUE);
   // Inicializamos la libreria, y asignamos un tile a todas las posiciones de la pantalla (el tile ' ')
   sp1_Initialize(SP1_IFLAG_MAKE_ROTTBL | SP1_IFLAG_OVERWRITE_TILES | SP1_IFLAG_OVERWRITE_DFILE, INK_BLUE | PAPER_CYAN, ' '); 
   // Ahora hacemos que el tile ' ' se represente por el patrón almacenado en el array fondo
   // Esto ha cambiado con respecto a la versión anterior de la librería, en la que esta operación se hacía antes del initialize
   // (además de tener la función un nombre totalmente diferente)
   sp1_TileEntry(' ',fondo); 
   // Invalidamos toda la pantalla para que se redibuje completamente en el próximo update
   sp1_Invalidate(&cr);
   sp1_UpdateNow();

   // El tercer parametro es la altura (tiene que valer uno mas de lo que realmente tiene, porque se deja
   // un caracter vacio por debajo de cada columna), El cuarto parametro es 16 (es el offset respecto a la direccion inicial del sprite)
   // Los dos primeros parametros indican que el modo de dibujo será con mascara, y que el sprite esta definido con dos bytes respectivamente
   p.sprite = sp1_CreateSpr(SP1_DRAW_MASK2LB, SP1_TYPE_2BYTE, 2, 16, 0);
   // El tercer parametro en la siguiente funcion es el numero de bytes que ocupa el sprite, sin contar el caracter en blanco que hay que contar
   // El segundo parametro siempre tiene que ser SP1_DRAW_MASK2RB para la utlima columna; las anteriores deben tener el valor SP1_DRAW_MASK2. 
   // Con RB se añade una columna en blanco al final, que antes era neceasrio y ahora ya no. 
   sp1_AddColSpr(p.sprite, SP1_DRAW_MASK2RB, 0, 16, 0);
   // los valores 12 y 16 representan el caracter donde se posiciona, y el 0 y 0 el offset en x y en y
   sp1_MoveSprAbs(p.sprite, &cr, prota_col0, 12, 16, 0, 0);
   p.dx = 0;
   p.dy = 0;

   // Creamos los enemigos
   for (i=0;i<6;i++)
   {
	enemigos[i].sprite = sp1_CreateSpr(SP1_DRAW_MASK2LB, SP1_TYPE_2BYTE, 2, 16, 0);
        sp1_AddColSpr(enemigos[i].sprite, SP1_DRAW_MASK2RB, 0, 16, 0);
	sp1_MoveSprAbs(enemigos[i].sprite, &cr, enemigo_col0, posiciones[2*i], posiciones[2*i+1], 0, 0);
        enemigos[i].dx = desplazamientos[2*i+1];
	enemigos[i].dy = desplazamientos[2*i];
   }

   sp1_Invalidate(&cr);
   sp1_UpdateNow();

   p.getjoy = in_JoyKeyboard;	/* Con esto decimos que el sprite se controla mediante teclado */
   p.keys.left = in_LookupKey('o');
   p.keys.right = in_LookupKey('p');
   p.keys.up = in_LookupKey('q');
   p.keys.down = in_LookupKey('a');
   p.keys.fire = in_LookupKey('m');
   p.frameoffset = (uchar *) 0;

   final = 0;
   while (!final)
   {
      sp1_UpdateNow();
      
      input = (p.getjoy)(&p.keys);
      if (input & in_RIGHT && !(p.sprite->col > 30 && p.sprite->hrot > 0))
	p.dx = 1;
      if (input & in_LEFT && !(p.sprite->col < 1 && p.sprite->hrot < 1))
	p.dx = -1;
      if (input & in_DOWN && !(p.sprite->row > 22))
        p.dy = 1;
      if (input & in_UP && !(p.sprite->row < 1 && p.sprite->vrot < 129)) // Para sprites definidos por 2 bytes, el bit 7 de vrot siempre vale 1
        p.dy = -1;
      
      sp1_MoveSprRel(p.sprite, &cr, p.frameoffset, 0, 0, p.dy, p.dx);
      p.dx = 0;
      p.dy = 0;

      // Calculamos el centro del sprite del protagonista
      xp = p.sprite->col*8 + p.sprite->hrot + 4;
      yp = p.sprite->row*8 + p.sprite->vrot + 4; // No hace falta controlar el 128

      // Movimiento de los enemigos
      for (i=0;i<6;i++)
      {
	 if (enemigos[i].sprite->col > 30 && enemigos[i].sprite->hrot > 0)
	    enemigos[i].dx = -enemigos[i].dx;
         if (enemigos[i].sprite->row > 22)
            enemigos[i].dy = -enemigos[i].dy;
   
         sp1_MoveSprRel(enemigos[i].sprite, &cr, enemigos[i].frameoffset, 0, 0, enemigos[i].dy, enemigos[i].dx);
         
         // Deteccion de colisiones, determinando si se produce una interseccion entre el rectangulo del personaje
         // y el del enemigo
         xe = enemigos[i].sprite->col*8 + enemigos[i].sprite->hrot;
         ye = enemigos[i].sprite->row*8 + enemigos[i].sprite->vrot;
         if (xe + 8  >= xp && xe <= xp && ye + 8 >= yp && ye <= yp)
         {
		zx_border(RED);
                final = 1;
         }	
      }
   }
   

}

#asm
._prota_col0
;Esto es la primera columna
; Cada linea se compone de dos bytes, el primero es la mascara y el segundo 
; es el sprite (se define como el tile de fondo). Este caracter tiene 8 lineas de alto (un caracter) (no tiene
; que haber 4 parejas de bytes por fila como en lso ejemplos que he visto)
	DEFB 255, 0, 255, 0, 255, 0, 255, 0
	DEFB 255, 0, 255, 0, 255, 0 ,255, 0
	DEFB 199,56,131,124,199,56,239,16
	DEFB 131,124,109,146,215,40,215,40
; Siempre tiene que haber un caracter vacio debajo
	DEFB 255,  0,255,  0,255,  0,255,  0
	DEFB 255,  0,255,  0,255,  0,255,  0

; Enemigos
._enemigo_col0
	DEFB 255, 0, 255, 0, 255, 0, 255, 0
	DEFB 255, 0, 255, 0, 255, 0, 255, 0
	DEFB 231,24,195,36,129,90,0,153
	DEFB 129,90,195,36,231,24,255,0
	DEFB 255,0,255,0,255,0,255,0
	DEFB 255,0,255,0,255,0,255,0
#endasm
