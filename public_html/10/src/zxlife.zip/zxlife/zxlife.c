/*
 *
 *  ZX-Life  -> Implementacion de ejemplo en C-Z88DK del
 *              simulador de vida de John Conway para
 *              MagazineZX (articulo programacion Z88DK).
 *              
 *  v 1.0     (c) 2004 Santiago Romero AkA NoP / Compiler
 *                       sromero@gmail.com
 *
*/
#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include "string.h"

//--- Variables y funciones utilizadas --------------------

#define ANCHO       32
#define ALTO        16
#define NUM_CELULAS 80

char mapa[ANCHO*ALTO], temp[ANCHO*ALTO];
unsigned char *memoffset;
unsigned char my_tmp_border;

#define Celula(x,y) (mapa[((y)<<5)+(x)])

#define TempCelula(x,y) (temp[((y)<<5)+(x)])

#define DrawCell(x,y,val) \
  *((unsigned char *) (0x4000 + 6144 + ((y)<<5) + (x))) = (val<<3) ;
  

void GenLife( void );
void DrawLife( void );
void Life( void );
void CLS( int value );
void BORDER( unsigned char value );
   

//--- Funcion principal main() ----------------------------
int main( void )
{
   int i;
   
   GenLife();
   
   while(1)
   {
      DrawLife();
      Life();
      if( getk() == 'r' )
         GenLife();
   }

   return(0);
}


//--- Rellenar el tablero con valores aleat. --------------
void GenLife( void )
{
   int x, y, i;

   // Inicializar la semilla de numeros aleatorios
   srand(clock());
   BORDER(0);
   CLS(0);
   printf( "\x1B[%u;%uH",(21),(1));
   printf("   ZX-Life - MagazineZX - Z88DK     ");
   printf(" (r) = nueva generacion aleatoria   ");
   
   // limpiamos el tablero de celulas
   for( i=0; i<ALTO*ANCHO; i++)
      mapa[i] = temp[i] = 0;

   // generamos unas cuantas celulas aleatorias
   for( i=0; i< NUM_CELULAS; i++)
   {
      x = (rand() % (ANCHO-2)) +1;
      y = (rand() % (ALTO-2)) +1;
      TempCelula(x,y) = Celula(x,y) = 1;
   }

}


//--- Funcion donde se simula la vida ---------------------
void Life( void )
{
   int x, y;
   int vecinos;

   // Calculamos la siguiente generacion
   for( y=0; y<ALTO; y++)
   {
      for( x=0; x<ANCHO ; x++)
      {
        // Las celulas del borde mueren
        if( x==0 || y==0 || x>ANCHO-2 || y>ALTO-2 )
           TempCelula(x,y)=0 ;

        else
        {
           // Obtenemos el numero de celulas vecinas
           vecinos = 0;
           vecinos += Celula(x-1,y);
           vecinos += Celula(x+1,y);
           vecinos += Celula(x,y-1);
           vecinos += Celula(x,y+1);
           vecinos += Celula(x-1,y+1);
           vecinos += Celula(x-1,y-1);
           vecinos += Celula(x+1,y-1);
           vecinos += Celula(x+1,y+1);

           // reglas para c�lulas vivas
           if( Celula(x,y) == 1 )
           {
              // celulas con 2 � 3 vecinos sobreviven
              // y el resto muere
              if( vecinos == 2 || vecinos == 3 )
                 TempCelula(x,y) = 1;
              else
                 TempCelula(x,y) = 0;
           }
        
           // reglas para espacios vacios
           else
           {
              // Espacios vacios con 3 vecinos dan lugar
              // a una nueva celula
              if( vecinos == 3 )
                 TempCelula(x,y) = 1;
            
           } // fin else espacios vacios
        } // fin else borrar celulas del borde
      } // fin for x
   } // fin for y
}

//--- Dibujar en pantalla el array de celulas -------------
void DrawLife( void )
{

   int x, y;
   for( y=0; y<ALTO; y++)
      for( x=0; x<ANCHO; x++)
      {
         Celula(x,y) = TempCelula(x,y);
         DrawCell(x,y,Celula(x,y));
      }
}


//--- Borrar la pantalla accediendo a la VRAM -------------
void CLS( int value )
{
#asm
   ld hl, 2
   add hl, sp
   ld a, (hl)
   ld hl, 16384
   ld (hl), a
   ld de, 16385
   ld bc, 6911
   ldir
#endasm
}


//--- Cambiar el borde de la pantalla ---------------------
void BORDER( unsigned char value )
{
   my_tmp_border = value<<3;
#asm
   ld hl, 2
   add hl, sp
   ld a, (hl)
   ld c, 254
   out (c), a
   ld hl, 23624
   ld a, (_my_tmp_border)
   ld (hl), a
#endasm
}


