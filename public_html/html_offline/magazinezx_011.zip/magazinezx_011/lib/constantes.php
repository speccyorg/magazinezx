<?php
//constantes.php

//texto en la barra de navegaci�n
define("TEXTO_NUMERO","N�mero 11 - Febrero 2005");

//n�mero de secciones de esta revista
$num_secciones=9;

//orden de aparici�n de las secciones
$orden_secciones=array(SECC_PORTADA,SECC_EDITORIAL,SECC_PANORAMA,SECC_ANALISIS,
						SECC_PATAS_ARRIBA,SECC_ZONAWWW,SECC_Z88DK,SECC_INPUT,
						SECC_OPINION);
												

?>
