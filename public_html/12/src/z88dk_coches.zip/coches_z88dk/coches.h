#define ALTURA_CIRCUITO 18
#define ANCHURA_CIRCUITO 24 

char sprite0[] = { 10, 10, 0x00 , 0x00 , 0x73 , 0x80 , 0xFF , 0x40 , 0xB9 , 0xC0 , 0xB9 , 0xC0 , 0xB9 
, 0xC0 , 0xB9 , 0xC0 , 0xFF , 0x40 , 0x73 , 0x80 , 0x00 , 0x00  };
char sprite1[] = { 10, 10, 0x3F , 0x00 , 0x5E , 0x80 , 0x7F , 0x80 , 0x61 , 0x80 , 0x21 , 0x00 , 0x3F 
, 0x00 , 0x7F , 0x80 , 0x7F , 0x80 , 0x61 , 0x80 , 0x3F , 0x00  };
char sprite2[] = { 10, 10, 0x00 , 0x00 , 0x73 , 0x80 , 0xBF , 0xC0 , 0xE7 , 0x40 , 0xE7 , 0x40 , 0xE7 
, 0x40 , 0xE7 , 0x40 , 0xBF , 0xC0 , 0x73 , 0x80 , 0x00 , 0x00  };
char sprite3[] = { 10, 10, 0x3F , 0x00 , 0x61 , 0x80 , 0x7F , 0x80 , 0x7F , 0x80 , 0x3F , 0x00 , 0x21 
, 0x00 , 0x61 , 0x80 , 0x7F , 0x80 , 0x5E , 0x80 , 0x3F , 0x00  };
char sprite4[] = { 10, 10, 0x0F , 0x00 , 0x1D , 0x80 , 0x13 , 0xC0 , 0x79 , 0x40 , 0xFC , 0xC0 , 0xBE 
, 0xC0 , 0xDF , 0x80 , 0x6E , 0x00 , 0x36 , 0x00 , 0x1C , 0x00  };
char sprite5[] = { 10, 10, 0x1C , 0x00 , 0x36 , 0x00 , 0x6E , 0x00 , 0xDF , 0x80 , 0xBE , 0xC0 , 0xFC 
, 0xC0 , 0x79 , 0x40 , 0x13 , 0xC0 , 0x1D , 0x80 , 0x0F , 0x00  };
char sprite6[] = { 10, 10, 0x3C , 0x00 , 0x6E , 0x00 , 0xF2 , 0x00 , 0xA7 , 0x80 , 0xCF , 0xC0 , 0xDF 
, 0x40 , 0x7E , 0xC0 , 0x1D , 0x80 , 0x1B , 0x00 , 0x0E , 0x00  };
char sprite7[] = { 10, 10, 0x0E , 0x00 , 0x1B , 0x00 , 0x1D , 0x80 , 0x7E , 0xC0 , 0xDF , 0x40 , 0xCF 
, 0xC0 , 0xA7 , 0x80 , 0xF2 , 0x00 , 0x6E , 0x00 , 0x3C , 0x00  };
char sprite8[] = { 10, 10, 0x1E , 0x00 , 0x7F , 0x80 , 0x7F , 0x80 , 0xF3 , 0xC0 , 0xE1 , 0xC0 , 0xE1 
, 0xC0 , 0xF3 , 0xC0 , 0x7F , 0x80 , 0x7F , 0x80 , 0x1E , 0x00  };

char *sprites[9] = { sprite0 , sprite1 , sprite2 , sprite3 , sprite4 , sprite5 , sprite6 , sprite7 , sprite8 };

int izquierda[] = {4,6,7,5,1,0,2,3};
int derecha[] = {5,4,6,7,0,3,1,2};

short circuito1[] =  { 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0 };
short circuito2[] =  { 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0 };
short circuito3[] =  { 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0 };
short circuito4[] =  { 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0 };
short circuito5[] =  { 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };
short circuito6[] =  { 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };
short circuito7[] =  { 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 }; 
short circuito8[] =  { 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1 }; 
short circuito9[] =  { 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1 }; 
short circuito10[] = { 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0 }; 
short circuito11[] = { 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0 };
short circuito12[] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0 };
short circuito13[] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0 }; 
short circuito14[] = { 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0 };
short circuito15[] = { 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0 };
short circuito16[] = { 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0 };
short circuito17[] = { 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
short circuito18[] = { 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };


short int *circuito[ALTURA_CIRCUITO] = {circuito1, circuito2, circuito3, circuito4, circuito5, circuito6, circuito7, circuito8, circuito9, circuito10, circuito11, circuito12, circuito13, circuito14, circuito15, circuito16, circuito17, circuito18};
