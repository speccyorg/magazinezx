#include "stdio.h"
#include "ctype.h"
#include "games.h"
#include "coches.h"

#define CICLOS_BASE 20;

void main(void)
{
	int x = 100;
	int y = 140;
	int x_anterior = x;
	int y_anterior = y;
	int posicion = 0;
	short int i;
	short int j;

	char *puntero1 = (char *) 23561;
	char *puntero2 = (char *) 23562;

	int girando = 0;
	int contador_izquierda = 0;
	int contador_derecha = 0;
	int velocidad = 0;
	int ciclos = CICLOS_BASE;

	for (i=0;i<30;i++)
		printf("\n");

	for (i=0;i<ALTURA_CIRCUITO;i++)
		for (j=0;j<ANCHURA_CIRCUITO;j++)
			if (circuito[i][j] == 1)
				putsprite(spr_xor,j*10+1,i*10+1,sprites[8]);	

	
	putsprite(spr_xor,x,y,sprites[0]);

	while(1)
	{
		*puntero1 = 1;
		*puntero2 = 1;
		asm("halt");
		
		girando = 0;
		
		switch(toupper(getk()))
		{
			case 'Q':
				if (velocidad < 30)
				{
					velocidad = velocidad + 1;
				}
				break;
			case 'A':
				if (velocidad > 0)
				{
					velocidad = velocidad - 1;
				}
				break;
			case 'O':
				contador_derecha = 0;
				contador_izquierda = contador_izquierda + 1;
				girando = 1;
				if (contador_izquierda == 3)
				{
					asm("halt");
					putsprite(spr_xor,x,y,sprites[posicion]);
					posicion = izquierda[posicion];
					putsprite(spr_xor,x,y,sprites[posicion]);
					contador_izquierda = 0;
				}
				break;
			case 'P':
				contador_izquierda = 0;
				contador_derecha = contador_derecha + 1;
				girando = 1;
				if (contador_derecha == 3)
				{
					asm("halt");
					putsprite(spr_xor,x,y,sprites[posicion]);
					posicion = derecha[posicion];
					putsprite(spr_xor,x,y,sprites[posicion]);
					contador_derecha = 0;
				}
				break;
		}
		
		if (girando == 0)
		{
			contador_izquierda = 0;
			contador_derecha = 0;
		}
		
		if (velocidad > 0)
		{
			ciclos = ciclos - velocidad;
			if (ciclos < 0)
			{
				ciclos = CICLOS_BASE;
				y_anterior = y;
				x_anterior = x;
				switch(posicion)
				{
					case 0:
						if (circuito[y/10][(x + 9)/10] == 1 || (y%10 != 0 && circuito[(y+7)/10][(x+9)/10] == 1)) 
							velocidad = 0;
						else
							x = x + 1;
						break;
					case 1:
						if (circuito[(y-2)/10][x/10] == 1 || (x%10 != 0 && circuito[(y-2)/10][(x+7)/10] == 1))
							velocidad = 0;
						else
							y = y - 1;
						break;
					case 2:
						if (circuito[y/10][(x-2)/10] == 1 || (y%10 != 0 && circuito[(y+7)/10][(x-2)/10] == 1))
							velocidad = 0;
						else
							x = x - 1;
						break;
					case 3:
						if (circuito[(y+9)/10][x/10] == 1 || (x%10 != 0 && circuito[(y+9)/10][(x+7)/10] == 1))
							velocidad = 0;
						else
							y = y + 1;
						break;
					case 4:
						if (circuito[y/10][(x + 9)/10] == 1 || (y%10 != 0 && circuito[(y+7)/10][(x+9)/10] == 1) || circuito[(y-2)/10][x/10] == 1 || (x%10 != 0 && circuito[(y-2)/10][(x+7)/10] == 1))
							velocidad = 0;
						else
						{
							x = x + 1;
							y = y - 1;
						}
						break;
					case 5:
						if (circuito[y/10][(x + 9)/10] == 1 || (y%10 != 0 && circuito[(y+7)/10][(x+9)/10] == 1) || circuito[(y+9)/10][x/10] == 1 || (x%10 != 0 && circuito[(y+9)/10][(x+7)/10] == 1))
							velocidad = 0;
						else
						{
							x = x + 1;
							y = y + 1;
						}
						break;
					case 6:
						if (circuito[y/10][(x-2)/10] == 1 || (y%10 != 0 && circuito[(y+7)/10][(x-2)/10] == 1) || circuito[(y-2)/10][x/10] == 1 || (x%10 != 0 && circuito[(y-2)/10][(x+7)/10] == 1))
							velocidad = 0;
						else
						{
							x = x - 1;
							y = y - 1;
						}
						break;
					case 7:
						if (circuito[y/10][(x-2)/10] == 1 || (y%10 != 0 && circuito[(y+7)/10][(x-2)/10] == 1) || circuito[(y+9)/10][x/10] == 1 || (x%10 != 0 && circuito[(y+9)/10][(x+7)/10] == 1))
							velocidad = 0;
						else
						{			
							x = x - 1;
							y = y + 1;
						}
						break;
				}
				asm("halt");
				putsprite(spr_xor,x_anterior,y_anterior,sprites[posicion]);
				putsprite(spr_xor,x,y,sprites[posicion]);
			}
		}
	}
}
