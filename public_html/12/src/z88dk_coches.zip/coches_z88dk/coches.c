#include "games.h"
#include "coches.h"

void main(void)
{
	putsprite(spr_or,1,41,sprite0);
	putsprite(spr_or,21,41,sprite1);
	putsprite(spr_or,41,41,sprite2);
	putsprite(spr_or,61,41,sprite3);
	putsprite(spr_or,1,61,sprite4);
	putsprite(spr_or,21,61,sprite5);
	putsprite(spr_or,41,61,sprite6);
	putsprite(spr_or,61,61,sprite7);
	putsprite(spr_or,1,81,sprite8);
}
