#include "stdio.h"
#include "ctype.h"
#include "games.h"
#include "coches.h"

#define CICLOS_BASE 20;

void main(void)
{
	int x = 100;
	int y = 100;
	int posicion = 0;

	char *puntero1 = (char *) 23561;
	char *puntero2 = (char *) 23562;


	int girando = 0;
	int contador_izquierda = 0;
	int contador_derecha = 0;
	int velocidad = 0;
	int ciclos = CICLOS_BASE;

	putsprite(spr_xor,x,y,sprites[0]);

	while(1)
	{
		*puntero1 = 1;
		*puntero2 = 1;
		asm("halt");
		
		girando = 0;
		
		switch(toupper(getk()))
		{
			case 'Q':
				if (velocidad < 30)
				{
					velocidad = velocidad + 1;
				}
				break;
			case 'A':
				if (velocidad > 0)
				{
					velocidad = velocidad - 1;
				}
				break;
			case 'O':
				contador_derecha = 0;
				contador_izquierda = contador_izquierda + 1;
				girando = 1;
				if (contador_izquierda == 3)
				{
					asm("halt");
					putsprite(spr_xor,x,y,sprites[posicion]);
					posicion = izquierda[posicion];
					putsprite(spr_xor,x,y,sprites[posicion]);
					contador_izquierda = 0;
				}
				break;
			case 'P':
				contador_izquierda = 0;
                                contador_derecha = contador_derecha + 1;
                                girando = 1;
                                if (contador_derecha == 3)
                                {
					asm("halt");
	                                putsprite(spr_xor,x,y,sprites[posicion]);
	                                posicion = derecha[posicion];
	                                putsprite(spr_xor,x,y,sprites[posicion]);
                                        contador_derecha = 0;
                                 }
                                 break;																				
		}
	
                if (girando == 0)
	        {
		        contador_izquierda = 0;
		        contador_derecha = 0;
		}
	      
		
		if (velocidad > 0)
		{
			ciclos = ciclos - velocidad;
			if (ciclos < 0)
			{
				ciclos = CICLOS_BASE;
				asm("halt");
				putsprite(spr_xor,x,y,sprites[posicion]);
				switch(posicion)
				{
					case 0:
						x = x + 1;
						break;
					case 1:
				y = y - 1;
						break;
					case 2:
						x = x - 1;
						break;
					case 3:
						y = y + 1;
						break;
					case 4:
						x = x + 1;
						y = y - 1;
						break;
					case 5:
						x = x + 1;
						y = y + 1;
						break;
					case 6:
						x = x - 1;
						y = y - 1;
						break;
					case 7:
						x = x - 1;
						y = y + 1;
						break;
				}
				putsprite(spr_xor,x,y,sprites[posicion]);
			}
		}
	}
}
