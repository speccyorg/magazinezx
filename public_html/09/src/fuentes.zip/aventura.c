#include "datos.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void inicializarHabitaciones(THabitacion habitaciones[])
{
	habitaciones[0].id = 1;
	strcpy(habitaciones[0].descripcion,"Te encuentras en la entrada de la taberna de Melee Island. Desde aqui puedes oler los vomitos de los borrachos que vas a encontrar en su interior.");
	habitaciones[0].direcciones[0] = 4;
	habitaciones[0].direcciones[1] = 2;
	habitaciones[0].direcciones[2] = 0;
	habitaciones[0].direcciones[3] = 0;

	habitaciones[1].id = 2;
	strcpy(habitaciones[1].descripcion,"Las sombras del callejon en el que te encuentras te sobrecogen. Estas rodeado de montones de basura.");
	habitaciones[1].direcciones[0] = 0;
	habitaciones[1].direcciones[1] = 0;
	habitaciones[1].direcciones[2] = 0;
	habitaciones[1].direcciones[3] = 1;

	habitaciones[2].id = 3;
	strcpy(habitaciones[2].descripcion,"Estas en uno de los dormitorios de la taberna. Varias literas estan alineadas, permitiendo a muchos piratas dormir juntos en una misma habitacion.");
	habitaciones[2].direcciones[0] = 0;
	habitaciones[2].direcciones[1] = 0;
	habitaciones[2].direcciones[2] = 0;
	habitaciones[2].direcciones[3] = 4;

	habitaciones[3].id = 4;
	strcpy(habitaciones[3].descripcion,"El salon principal de la taberna. Decenas de piratas se encuentran aqu� bebiendo, cantando, peleandose, vomitando, y metiendo mano a las doncellas del lugar. Si te diriges al norte, este u oeste podras visitar varias de las habitaciones del local.");
	habitaciones[3].direcciones[0] = 6;
	habitaciones[3].direcciones[1] = 3;
	habitaciones[3].direcciones[2] = 1;
	habitaciones[3].direcciones[3] = 5;

	habitaciones[4].id = 5;
	strcpy(habitaciones[4].descripcion,"Una gran cantidad de pucheros sucios estan amontonados en la cocina. Platos a medio comer, jarras medio llenas, y cubiertos sucios les hacen compa�ia.");
	habitaciones[4].direcciones[0] = 0;
	habitaciones[4].direcciones[1] = 4;
	habitaciones[4].direcciones[2] = 0;
	habitaciones[4].direcciones[3] = 0;
	
	habitaciones[5].id = 6;
	strcpy(habitaciones[5].descripcion,"Tras apartar una cortina accedes a un reservado. Es una zona exclusiva de la taberna a donde muy pocos piratas pueden acceder.");
	habitaciones[5].direcciones[0] = 0;
	habitaciones[5].direcciones[1] = 0;
	habitaciones[5].direcciones[2] = 4;
	habitaciones[5].direcciones[3] = 0;
}

void inicializarObjetos(TObjeto objetos[])
{
	char c[2];

	strcpy(objetos[0].nombre,"una espada");
	objetos[0].localizacion = 5;
	objetos[0].peso = 5;
	
	strcpy(objetos[1].nombre,"una jarra");
	objetos[1].localizacion = -1;
	objetos[1].peso = 3;
	
	c[0] = 27;
	c[1] = '\0';
	strcpy(objetos[2].nombre,"una antorcha ");
	strcat(objetos[2].nombre,c);
	strcat(objetos[2].nombre,"[44mapagada"); 
	strcat(objetos[2].nombre,c);
	strcat(objetos[2].nombre,"[47m");
	objetos[2].localizacion = 2;
	objetos[2].peso = 2;
	
	strcpy(objetos[3].nombre,"una antorcha ");
	strcat(objetos[3].nombre,c);
	strcat(objetos[3].nombre,"[43mencendida"); 
	strcat(objetos[3].nombre,c);
	strcat(objetos[3].nombre,"[47m");
	objetos[3].localizacion = -2;
	objetos[3].peso = 2;
}


void escribirDescripcion(THabitacion habitaciones, int habitacion, TObjeto objetos, int localizacionPirata)
{
	int hayObjetos = 0;
	int i;

	printf(habitaciones[habitacion].descripcion);
	printf("\n\n");
	printf("Salidas:");
	if (habitaciones[habitacion].direcciones[0] != 0) printf(" %c[4mNorte%c[24m",27,27);
	if (habitaciones[habitacion].direcciones[1] != 0) printf(" %c[4mEste%c[24m",27,27);
	if (habitaciones[habitacion].direcciones[2] != 0) printf(" %c[4mSur%c[24m",27,27);
	if (habitaciones[habitacion].direcciones[3] != 0) printf(" %c[4mOeste%c[24m",27,27);
	printf("\n\n");
	printf("En la habitacion puedes ver:");
	for (i=0;i<4;i++)
		if (objetos[i].localizacion == habitaciones[habitacion].id)
		{
			printf(" %s",objetos[i].nombre);
			hayObjetos = 1;
		}
	if (hayObjetos == 0)
		printf(" nada");
	printf("\n\n");	
	if (habitacion == localizacionPirata)
		printf("El pirata esta aqui.\n\n");
	
}

int movimientoPirata(int localizacionPirata, THabitacion habitaciones[], int habitacion)
{
	int probabilidadMovimiento;
	int localizacionAnterior = localizacionPirata;
	
	probabilidadMovimiento = rand()/(RAND_MAX/4);
	
	if (habitaciones[localizacionPirata].direcciones[probabilidadMovimiento] > 2)
	{
		localizacionPirata = habitaciones[localizacionPirata].direcciones[probabilidadMovimiento]-1;
		if (localizacionAnterior != localizacionPirata)
			if (localizacionPirata == habitacion)
				printf("El pirata entra en la habitacion.\n\n");
			else if (localizacionAnterior == habitacion)
			{
				printf("El pirata sale de la habitacion hacia el ");
				if (probabilidadMovimiento == 0) printf("norte.");
				else if (probabilidadMovimiento == 1) printf("este.");
				else if (probabilidadMovimiento == 2) printf("sur.");
				else printf("oeste");
				printf("\n\n");
			}
	}

	return localizacionPirata;
}

void main(void)
{
	int habitacion = 0;
	int final = 0;
	char comando[250];
	int i;
	int hayObjetos;
	char palabra[50];
	int pesoTransportado;
	int localizacionPirata = 5;
	short int borrachoPirata = 0;
	
	THabitacion habitaciones[6];
	TObjeto objetos[4];
	inicializarHabitaciones(habitaciones);
	inicializarObjetos(objetos);
	pesoTransportado = objetos[1].peso;

	escribirDescripcion(habitaciones,habitacion,objetos,localizacionPirata);
	while (final == 0)
	{
		localizacionPirata = movimientoPirata(localizacionPirata,habitaciones,habitacion);
		printf("Que hago ahora? - ");
		gets(comando);
		if (strcmp(comando,"m") == 0 || strcmp(comando,"mirar") == 0)
		{
			for (i=0;i<32;i++)
				printf("\n");
			escribirDescripcion(habitaciones,habitacion,objetos,localizacionPirata);
		}
		else if (strcmp(comando,"n") == 0 || strcmp(comando,"norte") == 0)
		{
			if (habitaciones[habitacion].direcciones[0] != 0)
			{
				habitacion = habitaciones[habitacion].direcciones[0] - 1;
				printf("\n\n");
				escribirDescripcion(habitaciones,habitacion,objetos,localizacionPirata);
			}
			else
				printf("\n\nNo puedo ir en esa direccion\n\n");
		}
		else if (strcmp(comando,"e") == 0 || strcmp(comando,"este") == 0)
		{
			if (habitaciones[habitacion].direcciones[1] != 0)
			{
				habitacion = habitaciones[habitacion].direcciones[1] - 1;
				printf("\n\n");
				escribirDescripcion(habitaciones,habitacion,objetos,localizacionPirata);
			}
			else
				printf("\n\nNo puedo ir en esa direccion\n\n");
		}
		else if (strcmp(comando,"s") == 0 || strcmp(comando,"sur") == 0)
		{
			if (habitaciones[habitacion].direcciones[2] != 0)
			{
				habitacion = habitaciones[habitacion].direcciones[2] - 1;
				printf("\n\n");
				escribirDescripcion(habitaciones,habitacion,objetos,localizacionPirata);
			}
			else
				printf("\n\nNo puedo ir en esa direccion\n\n");
		}
		else if (strcmp(comando,"o") == 0 || strcmp(comando,"oeste") == 0)
		{
			if (habitaciones[habitacion].direcciones[3] != 0)
			{
				habitacion = habitaciones[habitacion].direcciones[3] - 1;
				printf("\n\n");
				escribirDescripcion(habitaciones,habitacion,objetos,localizacionPirata);
			}
			else
				printf("\n\nNo puedo ir en esa direccion\n\n");
		}
		else if (strcmp(comando,"i") == 0 || strcmp(comando,"inventario") == 0)
		{
			hayObjetos = 0;
			printf("\n\nLlevas:");
			for (i = 0; i<4;i++)
				if (objetos[i].localizacion == -1)
				{
					printf(" %s",objetos[i].nombre);
					hayObjetos = 1;
				}
			if (hayObjetos == 0)
				printf(" nada");
			printf("\n\n");	
		}
		else if (strcmp(comando,"coger una antorcha") == 0)
		{
			if (objetos[2].localizacion == habitacion + 1)
			{
				if (objetos[2].peso + pesoTransportado <= 6)
				{
					objetos[2].localizacion = -1;
					printf("\n\nHe cogido %s\n\n",objetos[2].nombre);
					pesoTransportado += objetos[2].peso;
				}
				else
					printf("\n\nNo puedo transportar mas peso\n\n");
			}
			else if (objetos[3].localizacion == habitacion + 1)
			{
				if (objetos[3].peso + pesoTransportado <= 6)
				{
					objetos[3].localizacion = -1;
					printf("\n\nHe cogido %s\n\n",objetos[3].nombre);
					pesoTransportado += objetos[3].peso;
				}
				else
					printf("\n\nNo puedo transportar mas peso\n\n");
			}
			else
				printf("\n\nNo puedo hacer eso\n\n");
		}
		else if (strcmp(comando,"dejar una antorcha") == 0)
		{
			if (objetos[2].localizacion == -1)
			{
				objetos[2].localizacion = habitacion + 1;
				pesoTransportado -= objetos[2].peso;
				printf("\n\nHe dejado %s\n\n",objetos[2].nombre);
			}
			else if (objetos[3].localizacion == -1)
			{
				objetos[3].localizacion = habitacion + 1;
				pesoTransportado -= objetos[3].peso;
				printf("\n\nHe dejado %s\n\n",objetos[3].nombre);
			}
			else
				printf("\n\nNo puedo hacer eso\n\n");
		}
		else if (strcmp(comando,"encender antorcha") == 0)
		{
			if (objetos[2].localizacion == -1)
			{
				objetos[2].localizacion = -2;
				objetos[3].localizacion = -1;
				printf("\n\nHe encendido la antorcha\n\n");
			}
			else
				printf("\n\nNo puedo hacer eso\n\n");
		}
		else if (strcmp(comando,"apagar antorcha") == 0)
		{
			if (objetos[3].localizacion == -1)
			{
				objetos[3].localizacion = -2;
				objetos[2].localizacion = -1;
				printf("\n\nHe apagado la antorcha\n\n");
			}
			else
				printf("\n\nNo puedo hacer eso\n\n");
		}
		else if (localizacionPirata == habitacion)
		// comandos del pirata
		{
			if (!strcmp(comando,"dar jarra a pirata"))
			{
				if (objetos[1].localizacion == -1)
				{
					printf("\n\nEl pirata coge la jarra y se bebe su contenido...\n\n");
					sleep(1);
					printf("\n\n... el pirata sigue bebiendo...\n\n");
					sleep(1);
					printf("\n\n... el pirata tiene sintomas evidentes de embriaguez.\n\n");
					borrachoPirata = 1;			
					objetos[1].localizacion = -2;
					pesoTransportado -= objetos[1].peso;
				}
			}
			else if (!strcmp(comando,"luchar con pirata") || !strcmp(comando,"pelear con pirata"))
			{
				if (objetos[0].localizacion == -1)
				{
					if (borrachoPirata == 0)
					{
						printf("\n\nEl pirata te vence sin dificultades...\n\n");
					}
					else
					{
						final = 1;
						printf("\n\nEl pirata esta tan borracho que no puede ni aguantar la espada... \n\n");
						sleep(1);
						printf("\n\nTras un larga lucha...\n\n");
						sleep(1);
						printf("\n\nUna larga, larga, lucha...\n\n");
						sleep(1);
						printf("\n\nConsigues vencerle!!\n\n");
						sleep(2);
						printf("\n\n\n\nFELICIDADES. Has conseguido completar la aventura y convertirte en un GRAN pirata!\n\n");
					}
				}
			}
			else
			{
				strcpy(palabra,strtok(comando," "));
	                        if (strcmp(comando,"decir") == 0)
				{
					strcpy(palabra,strtok(0,"\0"));
					if (palabra == 0)
						printf("\n\nQue es lo que quieres decir?\n\n");
					else
					{
						if (!strcmp(palabra,"\"ayuda\""))
							printf("\n\nEl pirata dice \"venceme con la espada si deseas convertirte en un gran bucanero\"\n\n");
						else 
							printf("\n\nEl pirata no entiende lo que dices.\n\n");	
					}
				}
			}
				
		}
		else
		// Comandos con m�s de una palabra
		{
			strcpy(palabra,strtok(comando," "));
			if (strcmp(comando,"coger") == 0)
			{
				strcpy(palabra,strtok(0,"\0"));
				if (palabra == 0)
					printf("\n\nNecesito que me digas que tengo que coger\n\n");
				else
				{
					hayObjetos = 0;
					i = 0;
					while (hayObjetos == 0 && i<4)
					{
						if (strcmp(objetos[i].nombre,palabra) == 0 && objetos[i].localizacion == habitacion+1)
						{
							hayObjetos = 1;
							if (objetos[i].peso + pesoTransportado <= 6)
							{
								objetos[i].localizacion = -1;
								printf("\n\nHe cogido %s\n\n",palabra);
								pesoTransportado += objetos[i].peso;
							}
							else
								printf("\n\nNo puedo transportar mas peso\n\n");
						}
						i++;
					}
					if (hayObjetos == 0)
						printf("\n\nNo puedo hacer eso\n\n");
				}
			}
			else if (strcmp(comando,"dejar") == 0)
			{
				strcpy(palabra,strtok(0,"\0"));
				if (palabra == 0)
					printf("\n\nNecesito que me digas que tengo que dejar\n\n");
				else
				{
					hayObjetos = 0;
					i = 0;
					while (hayObjetos == 0 && i<4)
					{
						if (strcmp(objetos[i].nombre,palabra) == 0 && objetos[i].localizacion == -1)
						{
							objetos[i].localizacion = habitacion+1;
							hayObjetos = 1;
							pesoTransportado -= objetos[i].peso;
							printf("\n\nHe dejado %s\n\n",palabra);
						}
						i++;
					}
					if (hayObjetos == 0)
						printf("\n\nNo puedo hacer eso\n\n");
				}
			}
			else
				printf("\n\nNo entiendo lo que dices\n\n");
		}
		
	}
	

}




