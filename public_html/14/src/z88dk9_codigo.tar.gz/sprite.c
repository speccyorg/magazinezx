#include <spritepack.h> 
#pragma output STACKPTR=61440 

extern struct sp_Rect *sp_ClipStruct; 
#asm 
LIB SPCClipStruct 
._sp_ClipStruct         defw SPCClipStruct 
#endasm 


extern uchar sprite1[]; 
uchar fondo[] = {0x55,0xaa,0x55,0xaa,0x55,0xaa,0x55,0xaa}; 



void *my_malloc(uint bytes) 
{ 
	   return sp_BlockAlloc(0); 
} 


void *u_malloc = my_malloc; 
void *u_free = sp_FreeBlock; 
  


main() 
{ 
	   struct sp_SS *bicho; 


           #asm 
	   di 
	   #endasm 
	   sp_InitIM2(0xf1f1);
	   sp_CreateGenericISR(0xf1f1);
	   #asm
	   ei
	   #endasm

	   sp_TileArray(' ', fondo); 
	   sp_Initialize(INK_WHITE | PAPER_BLACK, ' '); 
	   sp_Border(BLACK); 
	   sp_AddMemory(0, 255, 14, 0xb000); 

	   bicho = sp_CreateSpr(sp_MASK_SPRITE, 1, sprite1, 1, TRANSPARENT); 
	   sp_MoveSprAbs(bicho, sp_ClipStruct, 0, 10, 15, 0, 0); 

	   sp_UpdateNow();

	   while(1);
} 
  


/* Sprite Graphics defined in some inline assembler */ 


#asm 

._sprite1 
defb @00111100, @11000011 
defb @01000010, @10000001 
defb @10000001, @00000000 
defb @10100101, @00000000 
defb @10000001, @00000000 
defb @10011001, @00000000 
defb @01011010, @10000001 
defb @00111100, @11011011 

#endasm
