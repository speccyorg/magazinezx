
#include <spritepack.h>
#include <stdlib.h>
#pragma output STACKPTR=61440

extern struct sp_Rect *sp_ClipStruct;
#asm
LIB SPCClipStruct
._sp_ClipStruct         defw SPCClipStruct
#endasm

extern uchar *sp_NullSprPtr; 
#asm 
LIB SPNullSprPtr 
._sp_NullSprPtr         defw SPNullSprPtr 
#endasm 

extern uchar bicho1[];
extern uchar bicho2[];
extern uchar bicho3[];
struct sp_UDK keys; 

uchar hash[] = {0x55,0xaa,0x55,0xaa,0x55,0xaa,0x55,0xaa};

void *my_malloc(uint bytes)
{
	   return sp_BlockAlloc(0);
}

void *u_malloc = my_malloc;
void *u_free = sp_FreeBlock;

uchar n; 
void addColour(struct sp_CS *cs)  
{ 
	   if (n == 0) 
	        cs->colour = INK_BLACK | PAPER_WHITE; 
	   else if (n == 1) 
	        cs->colour = INK_BLUE | PAPER_BLACK; 
	   else if (n == 2)
		 cs->colour = INK_RED | PAPER_GREEN;
	   else if (n == 3)
		 cs->colour = INK_YELLOW | PAPER_BLACK;
	   else if (n == 4)
		 cs->colour = INK_GREEN | PAPER_WHITE;
	   else 
	         cs->colour = TRANSPARENT; 
	   if (n > 5) 
	         cs->graphic = sp_NullSprPtr; 
	   n++; 
	   return; 
}

main()
{
	   char dx,dy,i
	   struct sp_SS *spriteBicho;
	   uint reset,cambioBorde; 
	   int borde = 1; 
	   

	    #asm
	    di
	    #endasm
	    sp_InitIM2(0xf1f1);
	    sp_CreateGenericISR(0xf1f1);
	    #asm
	    ei
	    #endasm
						    
	   sp_TileArray(' ', hash);
	   sp_Initialize(INK_WHITE | PAPER_BLACK, ' ');
	   sp_Border(BLUE);
	   sp_AddMemory(0, 255, 14, 0xb000);

           keys.up = sp_LookupKey('q'); 
	   keys.down = sp_LookupKey('a'); 
	   keys.right = sp_LookupKey('p'); 
	   keys.left = sp_LookupKey('o'); 
	   keys.fire = sp_LookupKey(' '); 
	   reset = sp_LookupKey('r'); 
	   cambioBorde = sp_LookupKey('b'); 
	   
           spriteBicho = sp_CreateSpr(sp_MASK_SPRITE, 3, bicho1, 1, TRANSPARENT);
           sp_AddColSpr(spriteBicho, bicho2, TRANSPARENT);
	   sp_AddColSpr(spriteBicho, bicho3, TRANSPARENT);
	   sp_IterateSprChar(spriteBicho, addColour); 
           sp_MoveSprAbs(spriteBicho, sp_ClipStruct, 0, 10, 15, 0, 0);

           while(1) {
  	         sp_UpdateNow();
   	         
		 
                 i  = sp_JoyKeyboard(&keys); 
                 if ((i & sp_FIRE) == 0) { 
	              dx = dy = 1; 
		 } else { 
		      dx = dy = 8; 
		 } 
           	 if ((i & sp_LEFT) == 0) 
		      dx = -dx; 
	         else if ((i & sp_RIGHT) != 0) 
		      dx = 0; 
	         if ((i & sp_UP) == 0) 
	              dy = -dy; 
                 else if ((i & sp_DOWN) != 0) 
                      dy = 0; 
                 if (sp_KeyPressed(reset)) 
	             sp_MoveSprAbs(spriteBicho, sp_ClipStruct, 0, 10, 15, 0, 0); 
      		 else 
	             sp_MoveSprRel(spriteBicho, sp_ClipStruct, 0, 0, 0, dx, dy);       
		 if (sp_KeyPressed(cambioBorde))
	             if (borde == 1)
		     {
			     borde = 2;
			     sp_Border(RED);
		     }
		     else
		     {
			     borde = 1;
			     sp_Border(BLUE);
		     }
	   }
}

#asm

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._bicho1
defb @00000011, @11111100
defb @00000100, @11111000
defb @00001000, @11110000
defb @00001011, @11110000
defb @00001011, @11110000
defb @00001000, @11110000
defb @00001000, @11110000
defb @00000100, @11111000

defb @00000011, @11111100
defb @00001100, @11110011
defb @00001100, @11110011
defb @00011000, @11100111
defb @00011000, @11100111
defb @01111100, @10000011
defb @01111100, @10000011
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._bicho2
defb @11100000, @00011111
defb @00010000, @00001111
defb @00001000, @00000111
defb @01101000, @00000111
defb @01101000, @00000111
defb @00001000, @00000111
defb @10001000, @00000111
defb @10010000, @00001111

defb @11100000, @00011111
defb @00011000, @11100111
defb @00011000, @11100111
defb @00001100, @11110011
defb @00001100, @11110011
defb @00111110, @11000001
defb @00111110, @11000001
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._bicho3
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

#endasm


