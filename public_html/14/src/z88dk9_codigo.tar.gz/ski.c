
#include <spritepack.h>
#include <stdlib.h>
#pragma output STACKPTR=61440

#define NUM_ROCAS 8

extern struct sp_Rect *sp_ClipStruct;
#asm
LIB SPCClipStruct
._sp_ClipStruct         defw SPCClipStruct
#endasm

extern uchar *sp_NullSprPtr; 
#asm 
LIB SPNullSprPtr 
._sp_NullSprPtr         defw SPNullSprPtr  
#endasm 

extern uchar roca1[];
extern uchar roca2[];
extern uchar roca3[];
extern uchar banderin1[];
extern uchar banderin2[];
extern uchar skiCentrado1[];
extern uchar skiCentrado2[];
extern uchar skiIzquierda1[];
extern uchar skiIzquierda2[];
extern uchar skiDerecha1[];
extern uchar skiDerecha2[];
struct sp_UDK keys; 

void *my_malloc(uint bytes)
{
	   return sp_BlockAlloc(0);
}

void *u_malloc = my_malloc;
void *u_free = sp_FreeBlock;

uchar n; 
void addColourRoca(struct sp_CS *cs)  
{ 
	   if (n >= 0 && n <= 5) 
		 cs->colour = INK_RED | PAPER_WHITE;
	   else 
	         cs->colour = TRANSPARENT; 
	   if (n > 5) 
	         cs->graphic = sp_NullSprPtr; 
	   n++; 
	   return; 
}

void addColourSki(struct sp_CS *cs)
{
	if (n == 0)
		cs->colour = INK_BLUE | PAPER_WHITE;
	else if (n == 2)
		cs->colour = INK_BLUE | PAPER_WHITE;
	else
		cs->colour = TRANSPARENT;
	if (n>2)
		cs->graphic = sp_NullSprPtr;
	n++;
	return;
}

main()
{
	   char dx,dy,i
	   struct sp_SS *spriteRoca[NUM_ROCAS], *spriteSkiCentrado, *spriteSkiIzquierda, *spriteSkiDerecha, *ski;
	   short int posicion = 0;
	   int roca = 0;
	   

	    #asm
	    di
	    #endasm
	    sp_InitIM2(0xf1f1);
	    sp_CreateGenericISR(0xf1f1);
	    #asm
	    ei
	    #endasm
						    
	   sp_Initialize(INK_BLACK | PAPER_WHITE, ' ');
	   sp_Border(WHITE);
	   sp_AddMemory(0, 255, 14, 0xb000);

	   keys.up = sp_LookupKey('q');
	   keys.down = sp_LookupKey('a');
	   keys.fire = sp_LookupKey(' ');
	   keys.right = sp_LookupKey('p'); 
	   keys.left = sp_LookupKey('o'); 
	   
	   for (i=0;i<NUM_ROCAS;i++)
	   {
              n = 0;
              spriteRoca[i] = sp_CreateSpr(sp_OR_SPRITE, 3, roca1, 1, TRANSPARENT);
              sp_AddColSpr(spriteRoca[i], roca2, TRANSPARENT);
	      sp_AddColSpr(spriteRoca[i], roca3, TRANSPARENT);
	      sp_IterateSprChar(spriteRoca[i], addColourRoca);
	      sp_MoveSprAbs(spriteRoca[i],sp_ClipStruct,0,0,-20,-20,0);
	   }

	   n = 0;
	   spriteSkiCentrado = sp_CreateSpr(sp_MASK_SPRITE, 2, skiCentrado1, 1, TRANSPARENT);
	   sp_AddColSpr(spriteSkiCentrado, skiCentrado2, TRANSPARENT);
	   sp_IterateSprChar(spriteSkiCentrado, addColourSki);
	  
	   n = 0;
	   spriteSkiIzquierda = sp_CreateSpr(sp_MASK_SPRITE, 2, skiIzquierda1, 1, TRANSPARENT);
	   sp_AddColSpr(spriteSkiIzquierda, skiIzquierda2, TRANSPARENT);
	   sp_IterateSprChar(spriteSkiIzquierda, addColourSki);

	   n = 0;
	   spriteSkiDerecha = sp_CreateSpr(sp_MASK_SPRITE, 2, skiDerecha1, 1, TRANSPARENT);
	   sp_AddColSpr(spriteSkiDerecha, skiDerecha2, TRANSPARENT);
	   sp_IterateSprChar(spriteSkiDerecha, addColourSki);
	   
	   ski = spriteSkiCentrado;
	   
           sp_MoveSprAbs(ski, sp_ClipStruct, 0, 0, 15, 0, 0);

	   
           while(1) {
  	         sp_UpdateNow();

		 i = sp_JoyKeyboard(&keys); 
		 dx = 0; 
		 dy = 0;
		 if ((i & sp_LEFT) == 0 && ski->col > 0) 
		 {
		    if (posicion != -1)
		    {
		    	sp_MoveSprAbs(spriteSkiIzquierda,sp_ClipStruct,0,ski->row,ski->col,0,0);
		    	sp_MoveSprAbs(ski,sp_ClipStruct,0,0,-10,0,0);
		    	ski = spriteSkiIzquierda;
			posicion = -1;
		    }
		    dx = -3; 
		 }
		 else if ((i & sp_RIGHT) == 0 && ski->col < 30) 
		 {
	            if (posicion != 1)
		    {
			sp_MoveSprAbs(spriteSkiDerecha,sp_ClipStruct,0,ski->row,ski->col,0,0);
			sp_MoveSprAbs(ski,sp_ClipStruct,0,0,-10,0,0);
			ski = spriteSkiDerecha;
			posicion = 1;
		    }
		    dx = 3;
		 }
		 else
		 {
		    if (posicion != 0)
		    {	
			    sp_MoveSprAbs(spriteSkiCentrado,sp_ClipStruct,0,ski->row,ski->col,0,0);
		            sp_MoveSprAbs(ski,sp_ClipStruct,0,0,-10,0,0);
		    	    ski = spriteSkiCentrado;
			    posicion = 0;
		    }
		 }
	         if (dx != 0) sp_MoveSprRel(ski, sp_ClipStruct, 0, 0, 0, dx, dy);       

		 if (spriteRoca[roca]->row != -10)
		 {
		    dx = 0;
		    dy = -4;
		    sp_MoveSprRel(spriteRoca[roca],sp_ClipStruct,0,0,0,dx,dy);
		 }
		 else
		    if (rand()%100>98)
		    {
			sp_MoveSprAbs(spriteRoca[roca],sp_ClipStruct,0,23,rand()%29+1,0,4);
		    }
 		 roca ++;
		 if (roca >= NUM_ROCAS)
	            roca = 0;		 
	   }
}

#asm

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._roca1
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000001, @11111110
defb @00000011, @11111100
defb @00000011, @11111100
defb @00000111, @11111000

defb @00001111, @11110000
defb @00001111, @11110000
defb @00011111, @11100000
defb @00111111, @11000000
defb @00111111, @11000000
defb @00111110, @11000000
defb @01111110, @10000000
defb @01111110, @10000000

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._roca2
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @01100000, @10011111
defb @11110000, @00001111
defb @11111000, @00000111
defb @11111000, @00000111
defb @10111000, @00000111

defb @10111100, @00000011
defb @10111100, @00000011
defb @10111100, @00000011
defb @01111110, @00000001
defb @01111110, @00000001
defb @11111110, @00000001
defb @11111111, @00000000
defb @11111111, @00000000

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._roca3
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._skiCentrado1
defb @00111110, @11000001
defb @01101011, @10000000
defb @00111110, @11000001
defb @00011100, @11100011
defb @00010100, @11101011
defb @00100010, @11011101
defb @00100010, @11011101
defb @01000001, @10111110

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._skiCentrado2
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._skiIzquierda1
defb @00011111, @11100000
defb @00110101, @11000000
defb @00011111, @11100000
defb @00001110, @11110001
defb @00010010, @11101101
defb @00100100, @11011011
defb @01001000, @10110111
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._skiIzquierda2
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._skiDerecha1
defb @11111000, @00000111
defb @10101100, @00000011
defb @11111000, @00000111
defb @01110000, @10001111
defb @01001000, @10110111
defb @00100100, @11011011
defb @00010010, @11101101
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

._skiDerecha2
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111
defb @00000000, @11111111

#endasm


