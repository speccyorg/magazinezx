#include <stdlib.h> 
#include <spritepack.h> 

#pragma output STACKPTR=61440 

main() 
{ 
   #asm 
   di 
   #endasm 
   sp_InitIM2(0xf1f1); 
   sp_CreateGenericISR(0xf1f1); 
   #asm 
   ei 
   #endasm 


   sp_Initialize(INK_BLACK | PAPER_WHITE, ' '); 
   while(1) { 
           sp_UpdateNow(); 
	   if (rand()%10 > 5)
	           sp_PrintAtInv(rand()%24, rand()%32, INK_RED | PAPER_CYAN, 'x'); 
	   else
		   sp_PrintAtInv(rand()%24, rand()%32, INK_CYAN | PAPER_RED, 'x'); 
	   sp_Pause(20); 
   }
}
